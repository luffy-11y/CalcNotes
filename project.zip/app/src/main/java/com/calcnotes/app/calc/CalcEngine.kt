package com.calcnotes.app.calc

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

enum class LineKind { EMPTY, TEXT, HEADING, SUM, AVG }

data class LineResult(val value: Double?, val kind: LineKind, val counted: Boolean = false)

data class NoteStats(
    val total: Double,
    val count: Int,
    val average: Double,
    val min: Double,
    val max: Double
)

data class Evaluation(val lines: List<LineResult>, val stats: NoteStats)

private sealed class Tok {
    class Num(val v: Double) : Tok()
    class Op(val c: Char) : Tok()
    class Fn(val name: String) : Tok()
    object LP : Tok()
    object RP : Tok()
    object Pct : Tok()
}

private class PV(val n: Double, val pct: Boolean = false)

private val FUNCS = setOf("sqrt", "abs", "round", "floor", "ceil")

private fun applyFn(name: String, x: Double): Double {
    return when (name) {
        "sqrt" -> sqrt(x)
        "abs" -> abs(x)
        "round" -> round(x)
        "floor" -> floor(x)
        "ceil" -> ceil(x)
        else -> x
    }
}

// Turns a line of free text into numbers and operators. Words are ignored.
private fun lex(s: String, vars: Map<String, Double>, prev: Double?): List<Tok> {
    val out = ArrayList<Tok>()
    val n = s.length
    var i = 0
    while (i < n) {
        val c = s[i]
        if (c.isDigit() || (c == '.' && i + 1 < n && s[i + 1].isDigit())) {
            var j = i
            val sb = StringBuilder()
            while (j < n) {
                val ch = s[j]
                if (ch.isDigit()) {
                    sb.append(ch)
                    j++
                } else if (ch == ',' && j > i && j + 3 < n &&
                    s[j + 1].isDigit() && s[j + 2].isDigit() && s[j + 3].isDigit() &&
                    (j + 4 >= n || !s[j + 4].isDigit())
                ) {
                    j++
                } else {
                    break
                }
            }
            if (j + 1 < n && s[j] == '.' && s[j + 1].isDigit()) {
                sb.append('.')
                j++
                while (j < n && s[j].isDigit()) {
                    sb.append(s[j])
                    j++
                }
            }
            var v = sb.toString().toDoubleOrNull() ?: 0.0
            if (j < n) {
                val mult = when (s[j]) {
                    'k', 'K' -> 1e3
                    'M' -> 1e6
                    'B' -> 1e9
                    else -> 1.0
                }
                if (mult != 1.0 && (j + 1 >= n || !s[j + 1].isLetter())) {
                    v *= mult
                    j++
                }
            }
            out.add(Tok.Num(v))
            i = j
        } else if (c == '-' && i > 0 && s[i - 1].isLetter()) {
            i++
        } else if (c == '+') {
            out.add(Tok.Op('+'))
            i++
        } else if (c == '-' || c == '\u2212' || c == '\u2013') {
            out.add(Tok.Op('-'))
            i++
        } else if (c == '*' || c == '\u00D7') {
            out.add(Tok.Op('*'))
            i++
        } else if (c == '/' || c == '\u00F7') {
            out.add(Tok.Op('/'))
            i++
        } else if (c == '^') {
            out.add(Tok.Op('^'))
            i++
        } else if (c == '(') {
            out.add(Tok.LP)
            i++
        } else if (c == ')') {
            out.add(Tok.RP)
            i++
        } else if (c == '%') {
            out.add(Tok.Pct)
            i++
        } else if (c.isLetter() || c == '_') {
            var j = i
            while (j < n && (s[j].isLetter() || s[j] == '_')) j++
            val lower = s.substring(i, j).lowercase()
            if (lower == "x") {
                out.add(Tok.Op('*'))
            } else if (lower == "of" && out.lastOrNull() is Tok.Pct) {
                out.add(Tok.Op('*'))
            } else if ((lower == "prev" || lower == "above") && prev != null) {
                out.add(Tok.Num(prev))
            } else if (lower in FUNCS && j < n && s[j] == '(') {
                out.add(Tok.Fn(lower))
            } else if (vars.containsKey(lower)) {
                out.add(Tok.Num(vars.getValue(lower)))
            }
            i = j
        } else {
            i++
        }
    }
    return out
}

private class Parser(private val t: List<Tok>) {
    private var pos = 0

    // Several numbers/expressions on one line are added together.
    fun evalAll(): Double? {
        var total = 0.0
        var any = false
        var guard = 0
        while (pos < t.size && guard < 1000) {
            guard++
            val before = pos
            val v = expr()
            if (v != null && v.n.isFinite()) {
                total += v.n
                any = true
            }
            if (pos == before) pos++
        }
        return if (any) total else null
    }

    private fun canStart(i: Int): Boolean {
        val tk = t.getOrNull(i) ?: return false
        return tk is Tok.Num || tk is Tok.LP || tk is Tok.Fn ||
            (tk is Tok.Op && (tk.c == '-' || tk.c == '+'))
    }

    private fun expr(): PV? {
        var left = term() ?: return null
        while (true) {
            val tk = t.getOrNull(pos)
            if (tk is Tok.Op && (tk.c == '+' || tk.c == '-') && canStart(pos + 1)) {
                pos++
                val right = term() ?: break
                left = if (right.pct && !left.pct) {
                    PV(if (tk.c == '+') left.n * (1 + right.n) else left.n * (1 - right.n))
                } else {
                    PV(if (tk.c == '+') left.n + right.n else left.n - right.n)
                }
            } else {
                break
            }
        }
        return left
    }

    private fun term(): PV? {
        var left = power() ?: return null
        while (true) {
            val tk = t.getOrNull(pos)
            if (tk is Tok.Op && (tk.c == '*' || tk.c == '/') && canStart(pos + 1)) {
                pos++
                val right = power() ?: break
                val r = if (tk.c == '*') {
                    left.n * right.n
                } else if (right.n != 0.0) {
                    left.n / right.n
                } else {
                    Double.NaN
                }
                left = PV(r)
            } else {
                break
            }
        }
        return left
    }

    private fun power(): PV? {
        val base = unary() ?: return null
        val tk = t.getOrNull(pos)
        if (tk is Tok.Op && tk.c == '^' && canStart(pos + 1)) {
            pos++
            val e = power() ?: return base
            return PV(base.n.pow(e.n))
        }
        return base
    }

    private fun unary(): PV? {
        val tk = t.getOrNull(pos)
        if (tk is Tok.Op && (tk.c == '-' || tk.c == '+')) {
            pos++
            val v = unary() ?: return null
            return if (tk.c == '-') PV(-v.n, v.pct) else v
        }
        return primary()
    }

    private fun primary(): PV? {
        val tk = t.getOrNull(pos) ?: return null
        if (tk is Tok.Num) {
            pos++
            if (t.getOrNull(pos) is Tok.Pct) {
                pos++
                return PV(tk.v / 100.0, true)
            }
            return PV(tk.v)
        }
        if (tk is Tok.LP) {
            pos++
            val inner = expr()
            if (t.getOrNull(pos) is Tok.RP) pos++
            return inner
        }
        if (tk is Tok.Fn) {
            pos++
            if (t.getOrNull(pos) is Tok.LP) pos++
            val inner = expr() ?: return null
            if (t.getOrNull(pos) is Tok.RP) pos++
            return PV(applyFn(tk.name, inner.n))
        }
        return null
    }
}

object CalcEngine {
    private val assign = Regex("^([A-Za-z_]+)\\s*=\\s*(.+)$")
    private val fmt = DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.US))

    fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return ""
        if (abs(v) < 0.005) return "0"
        return fmt.format(v)
    }

    fun evaluate(text: String): Evaluation {
        val rawLines = text.split("\n")
        val results = ArrayList<LineResult>(rawLines.size)
        val vars = HashMap<String, Double>()
        val block = ArrayList<Double>()
        val values = ArrayList<Double>()
        var prev: Double? = null

        for (raw in rawLines) {
            var line = raw.trim()
            if (line.startsWith("- ") || line.startsWith("* ")) {
                line = line.substring(2).trim()
            }
            val lower = line.lowercase()
            if (line.isEmpty()) {
                results.add(LineResult(null, LineKind.EMPTY))
                block.clear()
            } else if (line.startsWith("#")) {
                results.add(LineResult(null, LineKind.HEADING))
                block.clear()
            } else if (lower == "sum" || lower == "total") {
                if (block.isEmpty()) {
                    results.add(LineResult(null, LineKind.SUM))
                } else {
                    val v = block.sum()
                    results.add(LineResult(v, LineKind.SUM))
                    prev = v
                }
            } else if (lower == "avg" || lower == "average") {
                if (block.isEmpty()) {
                    results.add(LineResult(null, LineKind.AVG))
                } else {
                    val v = block.average()
                    results.add(LineResult(v, LineKind.AVG))
                    prev = v
                }
            } else {
                var body = line
                var name: String? = null
                val m = assign.find(line)
                if (m != null) {
                    name = m.groupValues[1].lowercase()
                    body = m.groupValues[2]
                }
                val toks = lex(body, vars, prev)
                val v = if (toks.isEmpty()) null else Parser(toks).evalAll()
                if (v == null) {
                    results.add(LineResult(null, LineKind.TEXT))
                } else if (name != null) {
                    vars[name] = v
                    results.add(LineResult(v, LineKind.TEXT, false))
                    prev = v
                } else {
                    block.add(v)
                    values.add(v)
                    prev = v
                    results.add(LineResult(v, LineKind.TEXT, true))
                }
            }
        }

        // Heading lines show the subtotal of everything under them.
        for (i in results.indices) {
            if (results[i].kind != LineKind.HEADING) continue
            var sum = 0.0
            var any = false
            var j = i + 1
            while (j < results.size && results[j].kind != LineKind.HEADING) {
                val r = results[j]
                val rv = r.value
                if (r.counted && rv != null) {
                    sum += rv
                    any = true
                }
                j++
            }
            if (any) results[i] = LineResult(sum, LineKind.HEADING)
        }

        val stats = if (values.isEmpty()) {
            NoteStats(0.0, 0, 0.0, 0.0, 0.0)
        } else {
            NoteStats(values.sum(), values.size, values.average(), values.min(), values.max())
        }
        return Evaluation(results, stats)
    }
}
