package com.calcnotes.app.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

val BgColor = Color(0xFF0A0A14)
val Accent = Color(0xFF8AB4FF)
val NumColor = Color(0xFF7DF0C8)
val OpColor = Color(0xFFFFB86B)

@Composable
fun CalcNotesTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = BgColor,
            surface = Color(0xFF16162A)
        )
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White, content = content)
    }
}
