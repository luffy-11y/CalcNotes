package com.calcnotes.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.calcnotes.app.data.NotesStore
import com.calcnotes.app.ui.AnimatedBackground
import com.calcnotes.app.ui.CalcNotesTheme
import com.calcnotes.app.ui.EditorScreen
import com.calcnotes.app.ui.NotesListScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = NotesStore(applicationContext)
        setContent {
            CalcNotesTheme {
                var openId by rememberSaveable { mutableStateOf<String?>(null) }
                AnimatedBackground {
                    Crossfade(targetState = openId, label = "screen") { id ->
                        val note = if (id != null) store.get(id) else null
                        if (note == null) {
                            NotesListScreen(
                                store = store,
                                onOpen = { openId = it },
                                onNew = { openId = store.create().id }
                            )
                        } else {
                            val close = {
                                val cur = store.get(note.id)
                                if (cur != null && cur.text.isBlank()) store.delete(note.id)
                                openId = null
                            }
                            BackHandler(onBack = close)
                            key(note.id) {
                                EditorScreen(
                                    initial = note.text,
                                    onTextChange = { store.updateText(note.id, it) },
                                    onBack = close
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
