package com.calcnotes.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.calcnotes.app.calc.CalcEngine
import com.calcnotes.app.calc.LineKind
import kotlin.math.abs
import kotlin.math.roundToInt

private val numRegex = Regex("[0-9][0-9,]*(\\.[0-9]+)?[kKMB]?|\\.[0-9]+")
private val opRegex = Regex("[+\\-*/^\u00D7\u00F7%=()]")

// Colours numbers and operators, dims the words.
private class CalcHighlighter : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val styled = buildAnnotatedString {
            append(s)
            for (m in numRegex.findAll(s)) {
                addStyle(SpanStyle(color = NumColor, fontWeight = FontWeight.Medium), m.range.first, m.range.last + 1)
            }
            for (m in opRegex.findAll(s)) {
                addStyle(SpanStyle(color = OpColor), m.range.first, m.range.last + 1)
            }
            var idx = 0
            for (ln in s.split("\n")) {
                if (ln.trimStart().startsWith("#")) {
                    addStyle(SpanStyle(color = Accent, fontWeight = FontWeight.Bold), idx, idx + ln.length)
                }
                idx += ln.length + 1
            }
        }
        return TransformedText(styled, OffsetMapping.Identity)
    }
}

@Composable
fun EditorScreen(initial: String, onTextChange: (String) -> Unit, onBack: () -> Unit) {
    var tfv by remember { mutableStateOf(TextFieldValue(initial)) }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val ev = remember(tfv.text) { CalcEngine.evaluate(tfv.text) }
    val clipboard = LocalClipboardManager.current
    val density = LocalDensity.current
    val focus = remember { FocusRequester() }
    val highlighter = remember { CalcHighlighter() }

    LaunchedEffect(Unit) {
        if (initial.isBlank()) {
            try {
                focus.requestFocus()
            } catch (e: Exception) {
                // focus will be requested when the user taps the field
            }
        }
    }

    fun insert(s: String) {
        val sel = tfv.selection
        val t = tfv.text.replaceRange(sel.min, sel.max, s)
        tfv = TextFieldValue(t, TextRange(sel.min + s.length))
        onTextChange(t)
    }

    val textStyle = TextStyle(
        color = Color.White.copy(alpha = 0.78f),
        fontSize = 18.sp,
        lineHeight = 26.sp
    )
    val textHeightDp = with(density) { (layout?.size?.height ?: 0).toDp() }

    val stats = ev.stats
    val animTotal by animateFloatAsState(
        targetValue = stats.total.toFloat(),
        animationSpec = tween(400),
        label = "total"
    )
    val shownTotal = if (abs(stats.total) < 100000.0) animTotal.toDouble() else stats.total

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCard(corner = 14.dp, onClick = onBack) {
                Text(
                    "\u2039  Notes",
                    fontSize = 16.sp,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
                )
            }
        }

        GlassCard(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            corner = 22.dp
        ) {
            Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Box(Modifier.weight(1f)) {
                        if (tfv.text.isEmpty()) {
                            Text(
                                "Try: 56 deepak",
                                style = textStyle,
                                color = Color.White.copy(alpha = 0.3f)
                            )
                        }
                        BasicTextField(
                            value = tfv,
                            onValueChange = {
                                val changed = it.text != tfv.text
                                tfv = it
                                if (changed) onTextChange(it.text)
                            },
                            textStyle = textStyle,
                            cursorBrush = SolidColor(Accent),
                            visualTransformation = highlighter,
                            onTextLayout = { layout = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 300.dp)
                                .focusRequester(focus)
                        )
                    }
                    Box(Modifier.width(128.dp).height(textHeightDp)) {
                        val lr = layout
                        if (lr != null) {
                            var start = 0
                            val logical = tfv.text.split("\n")
                            logical.forEachIndexed { idx, ln ->
                                val s = start
                                start += ln.length + 1
                                val r = ev.lines.getOrNull(idx)
                                val v = r?.value
                                if (r != null && v != null && s <= lr.layoutInput.text.length) {
                                    val top = lr.getLineTop(lr.getLineForOffset(s))
                                    val label = CalcEngine.format(v)
                                    val col = when (r.kind) {
                                        LineKind.HEADING -> Color(0xFFB9A7FF)
                                        LineKind.SUM, LineKind.AVG -> NumColor
                                        else -> Accent
                                    }
                                    Text(
                                        text = label,
                                        maxLines = 1,
                                        softWrap = false,
                                        textAlign = TextAlign.End,
                                        color = col,
                                        fontSize = 16.sp,
                                        lineHeight = 26.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = if (r.kind == LineKind.TEXT) FontWeight.Normal else FontWeight.Bold,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .offset { IntOffset(0, top.roundToInt()) }
                                            .clickable { clipboard.setText(AnnotatedString(label)) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassCard(
                corner = 16.dp,
                onClick = { clipboard.setText(AnnotatedString(CalcEngine.format(stats.total))) }
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text("TOTAL", fontSize = 11.sp, color = Color.White.copy(alpha = 0.55f))
                    Text(
                        CalcEngine.format(shownTotal),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = NumColor
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            if (stats.count > 1) {
                Text(
                    "${stats.count} lines \u00B7 avg ${CalcEngine.format(stats.average)} \u00B7 max ${CalcEngine.format(stats.max)}",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.55f),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp)
                .padding(bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val keys = listOf("+", "-", "\u00D7", "\u00F7", "(", ")", "%", "=", "#")
            for (k in keys) {
                GlassCard(corner = 12.dp, onClick = { insert(k) }) {
                    Text(
                        k,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}
