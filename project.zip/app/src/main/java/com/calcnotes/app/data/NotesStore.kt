package com.calcnotes.app.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Note(val id: String, val text: String, val pinned: Boolean, val updated: Long)

class NotesStore(context: Context) {
    private val prefs =
        context.applicationContext.getSharedPreferences("calcnotes", Context.MODE_PRIVATE)

    val notes = mutableStateListOf<Note>()

    init {
        try {
            val arr = JSONArray(prefs.getString("notes", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                notes.add(
                    Note(
                        o.getString("id"),
                        o.optString("text", ""),
                        o.optBoolean("pinned", false),
                        o.optLong("updated", 0L)
                    )
                )
            }
        } catch (e: Exception) {
            // start empty if the saved data is unreadable
        }
    }

    fun get(id: String): Note? = notes.firstOrNull { it.id == id }

    fun create(): Note {
        val n = Note(UUID.randomUUID().toString(), "", false, System.currentTimeMillis())
        notes.add(0, n)
        save()
        return n
    }

    fun updateText(id: String, text: String) {
        val i = notes.indexOfFirst { it.id == id }
        if (i < 0 || notes[i].text == text) return
        notes[i] = notes[i].copy(text = text, updated = System.currentTimeMillis())
        save()
    }

    fun togglePin(id: String) {
        val i = notes.indexOfFirst { it.id == id }
        if (i < 0) return
        notes[i] = notes[i].copy(pinned = !notes[i].pinned)
        save()
    }

    fun delete(id: String) {
        notes.removeAll { it.id == id }
        save()
    }

    private fun save() {
        val arr = JSONArray()
        for (n in notes) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("text", n.text)
            o.put("pinned", n.pinned)
            o.put("updated", n.updated)
            arr.put(o)
        }
        prefs.edit().putString("notes", arr.toString()).apply()
    }
}
