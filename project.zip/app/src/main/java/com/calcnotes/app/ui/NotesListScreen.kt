package com.calcnotes.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.calcnotes.app.calc.CalcEngine
import com.calcnotes.app.data.Note
import com.calcnotes.app.data.NotesStore
import java.text.DateFormat
import java.util.Date

@Composable
fun NotesListScreen(store: NotesStore, onOpen: (String) -> Unit, onNew: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var deleteId by remember { mutableStateOf<String?>(null) }

    val list = store.notes
        .filter { query.isBlank() || it.text.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updated })

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            Text(
                "CalcNotes",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp)
            )
            Text(
                "Type anything. The numbers add up.",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.55f),
                modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
            )

            GlassCard(Modifier.fillMaxWidth(), corner = 16.dp) {
                Box(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                    if (query.isEmpty()) {
                        Text("Search notes", color = Color.White.copy(alpha = 0.45f), fontSize = 16.sp)
                    }
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        cursorBrush = SolidColor(Accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Box(Modifier.padding(top = 14.dp).weight(1f)) {
                if (list.isEmpty()) {
                    Text(
                        if (query.isBlank()) "No notes yet.\nTap + to start." else "No matches.",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 16.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 110.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(list, key = { it.id }) { note ->
                            NoteCard(
                                note = note,
                                onOpen = { onOpen(note.id) },
                                onPin = { store.togglePin(note.id) },
                                onDelete = { deleteId = note.id }
                            )
                        }
                    }
                }
            }
        }

        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(20.dp)
                .size(62.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Accent, Color(0xFF9B7CFF))))
                .clickable(onClick = onNew),
            contentAlignment = Alignment.Center
        ) {
            Text("+", fontSize = 32.sp, color = Color.White)
        }
    }

    val toDelete = deleteId
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleteId = null },
            containerColor = Color(0xFF1B1B2F),
            title = { Text("Delete this note?") },
            text = { Text("This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(toDelete)
                    deleteId = null
                }) { Text("Delete", color = Color(0xFFFF7A8A)) }
            },
            dismissButton = {
                TextButton(onClick = { deleteId = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun NoteCard(note: Note, onOpen: () -> Unit, onPin: () -> Unit, onDelete: () -> Unit) {
    val ev = remember(note.text) { CalcEngine.evaluate(note.text) }
    val lines = note.text.split("\n").filter { it.isNotBlank() }
    val title = lines.firstOrNull()?.trimStart('#', ' ')?.trim().orEmpty().ifEmpty { "New note" }
    val snippet = lines.drop(1).take(2).joinToString("  \u00B7  ")
    val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(note.updated))

    GlassCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (snippet.isNotEmpty()) {
                    Text(
                        snippet,
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.55f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (ev.stats.count > 0) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NumColor.copy(alpha = 0.16f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                "= " + CalcEngine.format(ev.stats.total),
                                color = NumColor,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                    }
                    Text(date, fontSize = 12.sp, color = Color.White.copy(alpha = 0.4f))
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (note.pinned) "\u2605" else "\u2606",
                    fontSize = 22.sp,
                    color = if (note.pinned) Accent else Color.White.copy(alpha = 0.5f),
                    modifier = Modifier.clickable(onClick = onPin).padding(8.dp)
                )
                Text(
                    "\u2715",
                    fontSize = 16.sp,
                    color = Color.White.copy(alpha = 0.4f),
                    modifier = Modifier.clickable(onClick = onDelete).padding(8.dp)
                )
            }
        }
    }
}
